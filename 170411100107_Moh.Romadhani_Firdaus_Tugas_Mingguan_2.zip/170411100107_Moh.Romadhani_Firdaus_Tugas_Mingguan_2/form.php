<?php
function form(){?>
	<?php
		global $vname;
		global $vfname;
		global $vemail;
		global $vpassword;
		global $vcpassword;
	?>
	<form name="myform" action="prosesData.php" method="POST">
		<div> 
			<table class="error">
				<tr>
					<td><label for="surname">Surname</label></td>
					<td><input type="text" name="surname" id="surname" size="31" value="<?php if(isset($_POST['surname'])) echo($_POST['surname']) ?>"></td>
					<td style="color: red;"><?php echo "$vname"?></td>
				</tr>
				<tr>
					<td><label for="firstname">Firstname</label></td>
					<td><input type="text" name="firstname" id="firstname" size="31" value="<?php if(isset($_POST['firstname'])) echo($_POST['firstname']) ?>"><br></td>
					<td style="color: red;"><?php echo "$vfname"?></td>
				</tr>
				<tr>
					<td><label for="email">Email address</label></td>
					<td><input type="text" name="email" id="email" size="31" value="<?php if(isset($_POST['email'])) echo($_POST['email']) ?>"></td>
					<td style="color: red;"><?php echo "$vemail"?></td>
				</tr>
				<tr>
					<td><label for="password">Password</label></td>
					<td><input type="password" name="password" id="password" size="31" value="<?php if(isset($_POST['password'])) echo($_POST['password']) ?>"></td>
					<td style="color: red;"><?php echo ""?><?php echo "$vpassword"?></td>
				</tr>
				<tr>
					<td><label for="cpassword">Confirm Password</label></td>
					<td><input type="password" name="cpassword" id="cpassword" size="31" value="<?php if(isset($_POST['cpassword'])) echo($_POST['cpassword']) ?>"></td>
					<td style="color: red;"><?php echo "$vcpassword"?></td>
				</tr>
				<tr>
					<td></td>
					<td><input type="submit" name="submit" value="submit"/>
					<input type="reset" name="reset" value="reset"/>
					</td>
					<td></td>
				</tr>
			</table>
		</div>			
		<div class="field">
			<label>&nbsp;</label>
		</div>
	</form>
<?php } ?>