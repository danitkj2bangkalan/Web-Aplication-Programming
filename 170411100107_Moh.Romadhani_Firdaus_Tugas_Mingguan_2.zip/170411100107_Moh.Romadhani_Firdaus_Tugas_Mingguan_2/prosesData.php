<!DOCTYPE html>
<html lang="id" dir="ltr">
	<head>
		<title>Form Register</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="./form.css">
	</head>

	<body class = "body"> 
		<div>
			<h2>Person Detail</h2>
			<?php
				include 'validate.php';
				include 'form.php';
				$errors = array();
				if (isset($_POST['surname']) ||isset($_POST['firstname']) || isset($_POST['email']) || isset($_POST['password']) || isset($_POST['cpassword'])){
					validation_name($errors, $_POST, 'surname');
					validation_fname($errors, $_POST, 'firstname');
					validation_email($errors, $_POST, 'email');
					validation_password($errors, $_POST, 'password');
					validation_cpassword($errors, $_POST, 'cpassword');
				 	if ($errors){
						form();
				 	}
				 	else{
				 		echo 'Form submitted successfully with no errors';
				 	}
				}
				else{
					// tampilkan kembali form
					form();
				}
			?>
		</div>
	</body>
</html>