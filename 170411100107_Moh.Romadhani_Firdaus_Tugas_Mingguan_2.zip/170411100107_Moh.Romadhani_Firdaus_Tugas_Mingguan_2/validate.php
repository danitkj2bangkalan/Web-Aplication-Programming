<?php
	$vname;
	$vfname;
	$vemail;
	$vpassword;
	$vcpassword;
	function validation_name(&$errors, $field_list, $surname){
		global $vname;
		$pattern = "/^[a-zA-Z'-]+$/"; // format surname (alfabet)
		if (!isset($field_list[$surname]) ||empty($field_list[$surname])){
			$vname="field is required";
			$errors[$surname] = 'field is required';
		}
		else{
			if (!preg_match($pattern, $field_list[$surname])){
				$vname="field must contain alphabets only";
				$errors[$surname] = 'field must contain alphabets only';
			}
		}
	}

	function validation_fname(&$errors, $field_list, $firstname){
		global $vfname;
		$pattern = "/^[a-zA-Z'-]+$/"; // format surname (alfabet)
		if (!isset($field_list[$firstname]) ||empty($field_list[$firstname])){
			$vfname="field is required";
			$errors[$firstname] = 'field is required';
		}
		else{
			if (!preg_match($pattern, $field_list[$firstname])){
				$vfname="field must contain alphabets only";
				$errors[$firstname] = 'field must contain alphabets only';
			}
		}
	}

	function validation_email(&$errors, $field_list, $email){
		global $vemail;
		$pattern = "/^[a-zA-Z]+@+[a-zA-Z]+.+$/"; // format surname (alfabet)
		if (!isset($field_list[$email]) ||empty($field_list[$email])){
			$vemail="field is required";
			$errors[$email] = 'field is required';
		}
		else{
			if (!filter_var($field_list[$email], FILTER_VALIDATE_EMAIL)){
				$vemail="invalid email address";
				$errors[$email] = 'invalid email address';
			}
		}
	}

	function validation_password(&$errors, $field_list, $password){
		global $vpassword;
		if (!isset($field_list[$password]) ||empty($field_list[$password])){
			$vpassword="field is required";
			$errors[$password] = 'field is required';
		}
		else{
			if (!preg_match("/\w{6,20}/", $field_list[$password])){
				$vpassword="password entered was not 6 digits long";
				$errors[$password] = 'password entered was not 6 digits long';
			}
			else if (!preg_match("/[0-9]/", $field_list[$password])){
				$vpassword="field must contain numeric only";
				$errors[$password] = 'field must contain numeric only';
			}
		}
	}

	function validation_cpassword(&$errors, $field_list, $cpassword){
		global $vcpassword;
		if (!isset($field_list[$cpassword]) ||empty($field_list[$cpassword])){
			$vcpassword="field is required";
			$errors[$cpassword] = 'field is required';
		}
		else{
			if ($field_list['password'] != $field_list[$cpassword]){
				$vcpassword="password do not mutch";
				$errors[$cpassword] = 'password do not mutch';
			}
		}
	}
?>