<!DOCTYPE html>
<html lang="id" dir="ltr">
	<head>
		<title>Form Register</title>
		<meta charset="utf-8">
		<link rel="stylesheet" type="text/css" href="./form.css">
	</head>

	<body class = "body"> 
		<div >
			<h2>Person Detail</h2>
			<?php
				include 'validate.php';
				include 'form.php';
				$errors = array();
				if (isset($_POST['surname']) ||isset($_POST['firstname']) || isset($_POST['email']) || isset($_POST['password']) || isset($_POST['cpassword'])){
					vname($errors, $_POST, 'surname');
					vfname($errors, $_POST, 'firstname');
					vemail($errors, $_POST, 'email');
					vpassword($errors, $_POST, 'password');
					vcpassword($errors, $_POST, 'cpassword');
				 	if ($errors){
						form();
				 	}
				 	else{
				 		echo 'Form submitted successfully with no errors';
				 	}
				}
				else{
					// tampilkan kembali form
					form();
				}
			?>
		</div>
	</body>
</html>